package ma.fsr.soa.rendezvousserviceapi.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class RendezVousDto {
    private LocalDate dateRdv;
    private String status;
    private Long patientId;
    private Long medecinId;
}