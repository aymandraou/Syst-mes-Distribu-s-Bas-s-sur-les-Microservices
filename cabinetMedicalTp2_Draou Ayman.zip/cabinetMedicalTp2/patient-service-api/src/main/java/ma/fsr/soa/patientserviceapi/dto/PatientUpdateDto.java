package ma.fsr.soa.patientserviceapi.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class PatientUpdateDto {
    private String nom;
    private LocalDate dateNaissance;
    private String telephone;
    private String genre;
}