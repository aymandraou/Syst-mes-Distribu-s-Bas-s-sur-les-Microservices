package ma.fsr.soa.patientserviceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientServiceApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
