package ma.fsr.soa.cabinetrepo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabinetRepoApplicationTests {

    @Test
    void contextLoads() {
    }

}
