package ma.fsr.soa.cabinetrepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabinetRepoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CabinetRepoApplication.class, args);
    }

}
