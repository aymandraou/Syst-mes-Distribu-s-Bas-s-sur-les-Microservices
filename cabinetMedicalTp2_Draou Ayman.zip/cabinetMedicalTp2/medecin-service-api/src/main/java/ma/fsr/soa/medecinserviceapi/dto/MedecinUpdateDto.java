package ma.fsr.soa.medecinserviceapi.dto;

import lombok.Data;

@Data
public class MedecinUpdateDto {
    private String nom;
    private String email;
    private String specialite;
}