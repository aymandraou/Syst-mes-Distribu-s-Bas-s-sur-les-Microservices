package ma.fsr.soa.cabinetesb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabinetEsbApplicationTests {

    @Test
    void contextLoads() {
    }

}
