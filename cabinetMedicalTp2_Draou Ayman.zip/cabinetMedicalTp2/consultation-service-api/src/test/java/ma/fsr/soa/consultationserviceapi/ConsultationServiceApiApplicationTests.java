package ma.fsr.soa.consultationserviceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultationServiceApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
