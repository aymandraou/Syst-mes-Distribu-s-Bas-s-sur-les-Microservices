package ma.fsr.soa.consultationserviceapi.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class ConsultationDto {
    private Long rendezVousId;
    private LocalDate dateConsultation;
    private String rapport;
}