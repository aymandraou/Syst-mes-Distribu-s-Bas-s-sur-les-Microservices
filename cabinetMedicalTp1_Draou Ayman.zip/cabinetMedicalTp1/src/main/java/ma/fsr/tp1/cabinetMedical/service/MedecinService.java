package ma.fsr.tp1.cabinetMedical.service;

import ma.fsr.tp1.cabinetMedical.model.Medecin;
import ma.fsr.tp1.cabinetMedical.repository.MedecinRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedecinService {

    @Autowired
    private MedecinRepository medecinRepository;

    // Créer un médecin
    public Medecin creerMedecin(Medecin medecin) {
        return medecinRepository.save(medecin);
    }

    // Lister tous les médecins
    public List<Medecin> listerMedecins() {
        return medecinRepository.findAll();
    }

    // Trouver un médecin par ID
    public Medecin trouverMedecinParId(Long id) {
        return medecinRepository.findById(id).orElse(null);
    }
}