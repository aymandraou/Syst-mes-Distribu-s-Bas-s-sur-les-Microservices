package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.RendezVous;
import ma.fsr.tp1.cabinetMedical.service.RendezVousService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rendezvous")
public class RendezVousController {

    @Autowired
    private RendezVousService rendezVousService;

    // POST : Créer un rendez-vous
    @PostMapping
    public RendezVous creerRendezVous(@RequestBody RendezVous rendezVous) {
        return rendezVousService.creerRendezVous(rendezVous);
    }

    // GET : Lister tous les rendez-vous
    @GetMapping
    public List<RendezVous> listerRendezVous() {
        return rendezVousService.listerRendezVous();
    }
}