package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.Medecin;
import ma.fsr.tp1.cabinetMedical.service.MedecinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medecins")
public class MedecinController {

    @Autowired
    private MedecinService medecinService;

    // POST : Créer un médecin
    @PostMapping
    public Medecin creerMedecin(@RequestBody Medecin medecin) {
        return medecinService.creerMedecin(medecin);
    }

    // GET : Lister tous les médecins
    @GetMapping
    public List<Medecin> listerMedecins() {
        return medecinService.listerMedecins();
    }
}