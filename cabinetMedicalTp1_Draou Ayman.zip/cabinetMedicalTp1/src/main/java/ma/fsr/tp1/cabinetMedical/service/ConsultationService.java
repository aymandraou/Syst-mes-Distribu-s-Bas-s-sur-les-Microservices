package ma.fsr.tp1.cabinetMedical.service;

import ma.fsr.tp1.cabinetMedical.model.Consultation;
import ma.fsr.tp1.cabinetMedical.repository.ConsultationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConsultationService {

    @Autowired
    private ConsultationRepository consultationRepository;

    // Créer une consultation
    public Consultation creerConsultation(Consultation consultation) {
        return consultationRepository.save(consultation);
    }

    // Lister toutes les consultations
    public List<Consultation> listerConsultations() {
        return consultationRepository.findAll();
    }
}