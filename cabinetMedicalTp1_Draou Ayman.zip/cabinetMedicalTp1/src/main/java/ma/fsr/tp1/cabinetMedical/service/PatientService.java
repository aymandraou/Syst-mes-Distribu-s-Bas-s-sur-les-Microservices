package ma.fsr.tp1.cabinetMedical.service;

import ma.fsr.tp1.cabinetMedical.model.Patient;
import ma.fsr.tp1.cabinetMedical.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    // Créer un patient
    public Patient creerPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    // Lister tous les patients
    public List<Patient> listerPatients() {
        return patientRepository.findAll();
    }

    // Trouver un patient par ID
    public Patient trouverPatientParId(Long id) {
        return patientRepository.findById(id).orElse(null);
    }
}