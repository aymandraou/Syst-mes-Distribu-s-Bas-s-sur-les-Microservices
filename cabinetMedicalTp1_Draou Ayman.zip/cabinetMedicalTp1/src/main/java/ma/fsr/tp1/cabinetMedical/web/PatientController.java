package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.Patient;
import ma.fsr.tp1.cabinetMedical.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    // POST : Créer un patient
    @PostMapping
    public Patient creerPatient(@RequestBody Patient patient) {
        return patientService.creerPatient(patient);
    }

    // GET : Lister tous les patients
    @GetMapping
    public List<Patient> listerPatients() {
        return patientService.listerPatients();
    }

    // GET : Trouver un patient par ID
    @GetMapping("/{id}")
    public Patient trouverPatientParId(@PathVariable Long id) {
        return patientService.trouverPatientParId(id);
    }
}