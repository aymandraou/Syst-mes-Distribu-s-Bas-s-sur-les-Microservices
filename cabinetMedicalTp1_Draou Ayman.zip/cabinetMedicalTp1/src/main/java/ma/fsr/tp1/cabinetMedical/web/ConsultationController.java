package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.Consultation;
import ma.fsr.tp1.cabinetMedical.service.ConsultationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consultations")
public class ConsultationController {

    @Autowired
    private ConsultationService consultationService;

    // POST : Créer une consultation
    @PostMapping
    public Consultation creerConsultation(@RequestBody Consultation consultation) {
        return consultationService.creerConsultation(consultation);
    }

    // GET : Lister toutes les consultations
    @GetMapping
    public List<Consultation> listerConsultations() {
        return consultationService.listerConsultations();
    }
}