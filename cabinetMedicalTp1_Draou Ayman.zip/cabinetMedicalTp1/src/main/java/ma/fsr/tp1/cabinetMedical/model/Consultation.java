package ma.fsr.tp1.cabinetMedical.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Consultation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime dateConsultation;
    private String rapport;

    @OneToOne
    @JoinColumn(name = "rendezvous_id")
    private RendezVous rendezVous;

    public Consultation() {}

    public Consultation(LocalDateTime dateConsultation, String rapport, RendezVous rendezVous) {
        this.dateConsultation = dateConsultation;
        this.rapport = rapport;
        this.rendezVous = rendezVous;
    }

    // Getters et Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getDateConsultation() { return dateConsultation; }
    public void setDateConsultation(LocalDateTime dateConsultation) { this.dateConsultation = dateConsultation; }

    public String getRapport() { return rapport; }
    public void setRapport(String rapport) { this.rapport = rapport; }

    public RendezVous getRendezVous() { return rendezVous; }
    public void setRendezVous(RendezVous rendezVous) { this.rendezVous = rendezVous; }
}