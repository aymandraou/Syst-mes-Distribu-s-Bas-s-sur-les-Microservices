package ma.fsr.tp1.cabinetMedical.service;

import ma.fsr.tp1.cabinetMedical.model.RendezVous;
import ma.fsr.tp1.cabinetMedical.repository.RendezVousRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RendezVousService {

    @Autowired
    private RendezVousRepository rendezVousRepository;

    // Créer un rendez-vous
    public RendezVous creerRendezVous(RendezVous rendezVous) {
        return rendezVousRepository.save(rendezVous);
    }

    // Lister tous les rendez-vous
    public List<RendezVous> listerRendezVous() {
        return rendezVousRepository.findAll();
    }
}